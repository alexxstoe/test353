import jwt, { JwtPayload } from "jsonwebtoken";
import express, { Router, Request, Response, NextFunction } from 'express';
import { request } from "http";
// import { Request as ExpressRequest } from 'express';

import { StatusCodes } from "http-status-codes";
import { RequestWithSellerId, RequestWithUserId } from "src/interfaces/smtpInterfaces";
import { getSellerID } from "../models/sellerModel";


export const authCookie = (req: RequestWithUserId, res: Response, next: NextFunction) => {
    const token = req.cookies.token;

    // Check if token is provided
    if (!token) {
        return res.status(StatusCodes.NOT_FOUND).json({
            status: 'forbidden',
            message: 'No token provided'
        });
    }

    try {
        const decoded = jwt.verify(token, `${process.env.JWT_Token}`) as JwtPayload;

        //    console.log(decoded, 'decoded');

        if (decoded.userId) {
            req.userId = decoded.userId;
            req.user_type = decoded.user_type;

            next();
            return;
        }
    } catch (error) {
        console.error('Error verifying JWT token:', error);
    }

    return res.status(StatusCodes.NOT_FOUND).json({
        status: 'forbidden',
        message: 'Invalid or expired token'
    });
};
// export const isSeller = async (req: RequestWithSellerId, res: Response, next: NextFunction) => {
//     const token = req.cookies.token;

//     if (!token) {
//         return res.status(StatusCodes.FORBIDDEN).json({
//             status: 'forbidden',
//             message: 'No token provided'
//         });
//     }

//     try {
//         const decoded = jwt.verify(token, `${process.env.JWT_Token}`) as JwtPayload;

//         //  console.log(decoded, 'decoded');

//         if (decoded.user_type == 'SELLER') {
//             console.log('is seller')
//             const response: any = await getSellerID(decoded.userId);
//             console.log("getSellerID", response[0].sellerID)
//             req.sellerId = response.sellerID

//             next();
//             return;
//         }
//     } catch (error) {
//         console.error('Error verifying JWT token:', error);
//     }

//     return res.status(StatusCodes.FORBIDDEN).json({
//         status: 'forbidden',
//         message: 'Invalid or expired token'
//     });
// };



export const isSeller = async (req: RequestWithSellerId, res: Response, next: NextFunction) => {
    const token = req.cookies.token;

    if (!token) {
        return res.status(StatusCodes.FORBIDDEN).json({
            status: 'forbidden',
            message: 'No token provided'
        });
    }

    try {

        const decoded = await jwt.verify(token, `${process.env.JWT_Token}`) as JwtPayload;

        if (decoded.user_type === 'SELLER') {
            const response: any = await getSellerID(decoded.userId);
            req.sellerId = response[0].sellerID;
            next(); // Don't forget to call next() to proceed to the next middleware or route handler
        } else {
            res.status(403).json({ message: 'Unauthorized' });
        }
    } catch (error) {
        console.error('Error verifying token:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};
