const currentDate = new Date();

// Format the current date and time to 'YYYY-MM-DD HH:mm:ss'
export const formattedCurrentTime = currentDate.toISOString().slice(0, 19).replace('T', ' ');
