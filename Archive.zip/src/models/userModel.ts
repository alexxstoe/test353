import { loginData, registerData } from "../interfaces/smtpInterfaces";
import { executeQuery } from "../helpers/db";
import { formattedCurrentTime } from "../utils/time";
const IP = require('ip');




export const registerModel = async (data: registerData): Promise<boolean | "Email-already-exists"> => {
    try {

        const query1 = `select id from users where email = ? `;
        const param1 = [data.email];



        const emailExist: any = await executeQuery(query1, param1);
        if (emailExist[0]?.id) {
            return 'Email-already-exists'
        }

        const ipAddress = IP.address();

        let maxUser: any = await executeQuery(`SELECT (MAX(id) + 1 ) as max FROM users`);
        maxUser = maxUser[0].max;


        const query = `
            INSERT INTO users 
            (username, buyer_nickname, email, test_email, password, user_type, seller_share, btc_address, registration_ip, last_login_ip, created_at, updated_at) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `;

        // Prepare parameters for the query
        const params = [
            data.username,
            `buyer${maxUser}`,
            data.email,
            data.email,
            data.password,
            'BUYER',
            '0.00',
            '546457xg',
            ipAddress,
            ipAddress,
            formattedCurrentTime,
            formattedCurrentTime
        ];

        const result = await executeQuery(query, params);

        return true;
    } catch (error) {
        console.error('Error in registerModel:', error);
        return false;

        throw error; // Throw the error to be handled by the caller
    }
};


export const loginModel = async (data: loginData) => {
    let responseData: { status: string, user_type: string, userId: string } = {
        status: 'invalid',
        user_type: '',
        userId: ''
    };

    try {
        const ipAddress = IP.address();


        const query = `
        select id from users where email = ?   
        `;

        const params = [
            data.email,
        ];

        const isValidEmail: any = await executeQuery(query, params);
        console.log("isValidEmail", isValidEmail[0]?.id);

        if (isValidEmail) {

            const query2 = `
            select password, user_type, id from users where email = ?   
            `;

            const params2 = [
                data.email,
            ];

            const isValidPass: any = await executeQuery(query2, params2);

            if (isValidPass[0].password == data.password) {
                responseData.status = 'success';
                responseData.user_type = isValidPass[0].user_type
                responseData.userId = isValidPass[0].id
                return responseData

            }
        }

        return responseData;
    } catch (error) {
        console.error('Error in loginModel:', error);
        return responseData;

        throw error; // Throw the error to be handled by the caller
    }
};



