import { SmtpData } from "../interfaces/smtpInterfaces";
import { executeQuery } from "../helpers/db";
import { getCurrentDateTime } from "../helpers/currentTime";






export const blockLogInsert = async (status: string | undefined, addr: any, btcValue: number | undefined, txid: any) => {
    // const seller_id = sellerId;

    const query =
        `
        INSERT INTO block_logs (txid, addr, value, status) 
        VALUES (?, ?, ?, ?);
            `;

    const params = [txid, addr, btcValue, status];

    try {
        let data = await executeQuery(query, params); // Execute query
        // console.log('dataaaaa', data);
        return data;
    } catch (error) {
        console.error('Error occurred while inserting data:', error);
        return error; // Return the error
    }
}


