import { SmtpData } from "../interfaces/smtpInterfaces";
import { executeQuery } from "../helpers/db";
import { getCurrentDateTime } from "../helpers/currentTime";




// export const massSmtpModel = async (host: any, port: any, user: any, pass: any, source: any, price: any, whoisInfo: any, isWebmail: any, sellerId: string | undefined) => {



//     const seller_id = sellerId;
//     const country_id = whoisInfo.location.country;
//     const username = user;
//     const password = pass;
//     const smtp_status = 'UNSOLD';
//     const detected_hosting = whoisInfo.isp || 'detected_hosting_value';
//     const webmail = isWebmail == true ? 'yes' : 'no';
//     const sold_at = null;
//     const buyer_user_id = null;
//     const created_at = getCurrentDateTime();
//     const updated_at = getCurrentDateTime();

//     // console.log('valid is', host)
//     // console.log('whois is', whoisInfo)
//     // console.log('whois host is', whoisInfo.isp)
//     // console.log("seller_idseller_idseller_idseller_idseller_id", seller_id)

//     const query =
//         `INSERT INTO smtp (seller_id, country_id, host, port, username, password, price, smtp_status, detected_hosting, webmail, sold_at, buyer_user_id, created_at, updated_at, category)
//     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;

//     const params = [seller_id, country_id, host, port, username, password, price, smtp_status, detected_hosting, webmail, sold_at, buyer_user_id, created_at, updated_at, source];

//     let data = await executeQuery(query, params); // Execute query
//     console.log('dataaaaa', data);
//     return data;
// }

export const massSmtpModel = async (host: any, port: any, user: any, pass: any, source: any, price: any, whoisInfo: any, isWebmail: any, sellerId: string | undefined) => {
    // const seller_id = sellerId;
    const seller_id = 123;
    const country_id = whoisInfo.location.country;
    const username = user;
    const password = pass;
    const smtp_status = 'UNSOLD';
    const detected_hosting = whoisInfo.isp || 'detected_hosting_value';
    const webmail = isWebmail == true ? 'yes' : 'no';
    const sold_at = null;
    const buyer_user_id = null;
    const created_at = getCurrentDateTime();
    const updated_at = getCurrentDateTime();

    const query =
        `INSERT INTO smtp (seller_id, country_id, host, port, username, password, price, smtp_status, detected_hosting, webmail, sold_at, buyer_user_id, created_at, updated_at, category)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;

    const params = [seller_id, country_id, host, port, username, password, price, smtp_status, detected_hosting, webmail, sold_at, buyer_user_id, created_at, updated_at, source];

    try {
        let data = await executeQuery(query, params); // Execute query
        // console.log('dataaaaa', data);
        return data;
    } catch (error) {
        console.error('Error occurred while inserting data:', error);
        return error; // Return the error
    }
}


export const userData = async (userId: string | undefined) => {
    const query = `
    SELECT 
    test_email,
    COALESCE((SELECT balance FROM balance WHERE user_id = ?), 0) AS balance
FROM
    users
WHERE
    id = ?;
  
`;
    const params = [userId, userId];

    try {
        const data: any = await executeQuery(query, params);
        return data;
    } catch (error) {
        console.error('Error fetching userData:', error);
        throw error;
    }
}
export const SmtpListModel = async (filter: any) => {
    let { hosting, location } = filter;

    console.log(hosting, location);

    const query = `
    SELECT t1.id, t1.category as source, t1.detected_hosting,t3.nicename as location, t1.price, t2.seller_nickname as seller, t1.webmail,t1.created_at 
    FROM smtp t1
    join users t2 on t1.seller_id = t2.seller_number
JOIN country t3 ON t3.iso = t1.country_id COLLATE utf8mb4_general_ci
     where t1.smtp_status = 'UNSOLD'
    LIMIT 100;

        
    `;

    try {
        const data: any = await executeQuery(query);
        return data;
    } catch (error) {
        console.error('Error fetching SMTP list:', error);
        throw error;
    }
}
export const dashboardDataModel = async () => {
    const query = `
    select count(*) 
    AS smtpCount 
    FROM smtp where smtp_status = 'UNSOLD' ; 
    `;


    try {
        const data: any = await executeQuery(query);
        return data;
    } catch (error) {
        console.error('Error fetching dashboardDataModel()', error);
        throw error;
    }
}
export const userStats = async (userId: string | undefined) => {
    //     const query = `
    //     SELECT   
    //     t1.balance as balance , t2.user_type , t2.email, COUNT(t3.id) as orders, COUNT(t4.id) as tickets    
    //    from balance t1
    //    right join users t2 on t2.id = t1.user_id 
    //    join user_orders t3 on t3.buyer_user_id = t2.id
    //    join tickets t4 on t4.assigned_id = t2.id
    //      where t2.id = ?
    //    ;
    //                        `;
    const query = `
    SELECT   
    UB.balance,
    UB.user_type,
    UB.email,
    COALESCE(UO.orders, 0) AS orders,
    COALESCE(UT.tickets, 0) AS tickets
FROM 
    (SELECT   
        t1.balance AS balance,
        t2.user_type,
        t2.email
    FROM 
        balance t1
    RIGHT JOIN 
        users t2 ON t2.id = t1.user_id 
    WHERE 
        t2.id = 34) AS UB
LEFT JOIN
    (SELECT COUNT(*) AS orders FROM user_orders WHERE buyer_user_id = ?) AS UO ON 1=1
LEFT JOIN
    (SELECT COUNT(*) AS tickets FROM tickets WHERE assigned_id = ?) AS UT ON 1=1;
   ;
                       `;
    const params = [userId, userId]

    try {
        const data: any = await executeQuery(query, params);
        return data[0];
    } catch (error) {
        console.error('Error fetching dashboardDataModel()', error);
        throw error;
    }
}




export const smtpData = async (smtpId: string | undefined, userId: string | undefined) => {
    // const query = `
    // select host, port, username, password  
    // from smtp 
    // where id=?
    // `;
    const query = `
    select host, port, username, password, (select test_email  from users where id = ?) as test_email 
    from smtp 
    where id=?
	;
    `;
    const params = [userId, smtpId];

    try {
        const data: any = await executeQuery(query, params);
        return data;
    } catch (error) {
        console.error('Error fetching userData:', error);
        throw error;
    }
}
export const deleteSmtpById = async (smtpId: string | undefined) => {
    const query = `
    UPDATE smtp 
    SET smtp_status = 'DELETED' 
    WHERE id = ? ;
        `;
    const params = [smtpId];

    try {
        const data: any = await executeQuery(query, params);
        return data;
    } catch (error) {
        console.error('Error fetching deleteSmtpById():', error);
        throw error;
    }
}