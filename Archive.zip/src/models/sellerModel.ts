import { executeQuery } from "../helpers/db";




export const getSellerID = async (userId: string | undefined) => {
    try {

        const query = `
        select seller_number as sellerID from users where id = ? ;
        `;
        console.log('userId=>', userId)
        const param = [userId];
        const result = await executeQuery(query, param);

        return result;
    } catch (error) {
        console.error('Error in getSellerID()', error);
        return false;

        throw error; // Throw the error to be handled by the caller
    }
};






