import { SmtpData } from "../interfaces/smtpInterfaces";
import { executeQuery } from "../helpers/db";
import { getCurrentDateTime } from "../helpers/currentTime";
import { formattedCurrentTime } from "../utils/time";
const IP = require('ip');



export const updateTestMailModel = async (smtpId: string | undefined, email: string | undefined) => {

    const query = `
    UPDATE users 
    SET test_email  = ?
    WHERE id = ? ;

           `;
    const params = [email, smtpId];

    try {
        const data: any = await executeQuery(query, params);
        return data;
    } catch (error) {
        console.error('Error fetching updateTestMailModel():', error);
        throw error;
    }
}
export const buyProductModel = async (productId: string | undefined, userId: string | undefined) => {
    const ipAddress = IP.address();

    const query = `
    INSERT INTO user_orders (
        tools_types,
        tools_id,
        buyer_user_id,
        seller_user_id,
        order_amount,
        user_ip,
        order_status,
        created_at
    ) VALUES (
        (select id from tools_types where ttypes_title = ?),
        ?, 
        ?, 
        (select seller_id from smtp where id = ?), 
        (select price from smtp where id = ?), 
        ?, 
        'PROCESSING' ,
        ?
        );
    
           `;
    const params = [
        'SMTP',
        productId, userId,
        productId,
        productId,
        ipAddress,
        formattedCurrentTime];

    try {
        const data: any = await executeQuery(query, params);
        return data;
    } catch (error) {
        console.error('Error fetching buyProductModel():', error);
        throw error;
    }
}
export const userOrderEligible = async (productId: string | undefined, userId: string | undefined) => {
    const ipAddress = IP.address();

    const query = `
    SELECT 
    (SELECT t1.balance 
     FROM balance t1
     JOIN users t2 ON t2.id = t1.user_id 
     WHERE t2.id = ?
    ) AS user_balance,
    (SELECT price 
     FROM smtp 
     WHERE id = ?
    ) AS smtp_price,
    (SELECT smtp_status 
     FROM smtp 
     WHERE id = ?
    ) AS smtp_status,
    CASE
        WHEN EXISTS (
            SELECT id 
            FROM user_orders 
            WHERE tools_id = ?
        ) THEN 'YES'
        ELSE 'NO'
    END AS isInOrders;
           `;
    const params = [
        userId, productId, productId, productId
    ];

    try {
        const data: any = await executeQuery(query, params);
        return data[0];
    } catch (error) {
        console.error('Error fetching userOrderEligible():', error);
        throw error;
    }
}
export const changeStatusSold = async (productId: string | undefined) => {

    const query = `
    UPDATE smtp
    SET smtp_status ='SOLD'
    WHERE id=?;
        
           `;
    const params = [
        productId
    ];

    try {
        const data: any = await executeQuery(query, params);
        return data;
    } catch (error) {
        console.error('Error fetching changeStatusSold():', error);
        throw error;
    }
}
export const buyerBalanceAfterBuy = async (userId: string | undefined, newBalance: any) => {

    const query = `
    UPDATE balance
    SET 
        balance = ?,
        last_updated = ?
    WHERE user_id = ?;

           `;
    const params = [
        newBalance,
        formattedCurrentTime,
        userId,
    ];

    try {
        const data: any = await executeQuery(query, params);
        return data;
    } catch (error) {
        console.error('Error fetching buyerBalanceAfterBuy():', error);
        throw error;
    }
}





export const getOrdersList = async (userId: string | undefined) => {

    const query = `
    SELECT host, port, username, password
FROM smtp
WHERE id IN (
    SELECT tools_id
    FROM user_orders
    WHERE buyer_user_id = ?
);


    `;
    const params = [
        userId
    ];

    try {
        const data: any = await executeQuery(query, params);
        return data;
    } catch (error) {
        console.error('Error fetching getOrdersList():', error);
        throw error;
    }
}
export const getOrdersCount = async (userId: string | undefined) => {

    const query = `
    select count(*) as orderCount from user_orders 
    where buyer_user_id = ?
    ;
    `;
    const params = [
        userId
    ];

    try {
        const data: any = await executeQuery(query, params);
        return data[0];
    } catch (error) {
        console.error('Error fetching getOrdersCount():', error);
        throw error;
    }
}



export const insertInvoiceLog = async (newUUID: any, userId: string | undefined, usdAmount: number | undefined, newAddress: string | undefined, ipAddress: string | undefined) => {

    const query = `
    INSERT INTO buyer_wallet_logs (id, buyer_id,  transaction_type, amount,  bitcoin_address,  user_ip) 
    VALUES (?, ?,  ?, ?, ?, ?);
    
    
           `;
    const params = [
        newUUID,
        userId,
        'deposit',
        usdAmount,
        newAddress,
        ipAddress,
    ];

    try {
        const data: any = await executeQuery(query, params);
        return data;
    } catch (error) {
        console.error('Error fetching insertInvoiceLog():', error);
        throw error;
    }
}
export const updateInvoiceLog = async (status: string | undefined, addr: any, usdAmount: number | undefined, txid: any, balanceNow: any, newBalance: any) => {

    const query = `
    UPDATE buyer_wallet_logs
    SET transaction_id = ?,
        paid_at = ?,
        opening_balance = ?,
        closing_balance = ?,
        updated_at = ?,
        received_value = ?
    WHERE bitcoin_address = ?;
        
    `;

    const params = [
        txid,
        formattedCurrentTime,
        balanceNow,
        newBalance,
        formattedCurrentTime,
        usdAmount,
        addr
    ];

    try {
        const data: any = await executeQuery(query, params);
        return data;
    } catch (error) {
        console.error('Error fetching updateInvoiceLog():', error);
        throw error;
    }
}
export const buyerCurrentBalance = async (addr: any) => {

    const query = `
    SELECT COALESCE(t1.balance, 0) AS balance, t1.user_id
    FROM buyer_wallet_logs t2
    LEFT JOIN balance t1 ON t2.buyer_id = t1.user_id
    WHERE t2.bitcoin_address = ?;
            
    `;

    const params = [
        addr,
    ];

    try {
        const data: any = await executeQuery(query, params);
        return data[0];
    } catch (error) {
        console.error('Error fetching buyerCurrentBalance():', error);
        throw error;
    }
}



export const insertBuyLog = async (
    userId: string | undefined,
    newBalance: any,
    userEligible: any,
    orderId: any,
    ipAddress: string | undefined) => {

    const query = `
    INSERT INTO buyer_wallet_logs (buyer_id,  transaction_type, amount,  opening_balance, closing_balance,  user_ip, order_id, created_at, updated_at) 
    VALUES (?,  ?, ?, ?, ?, ?, ?, ?, ?);
           `;
    const params = [
        userId,
        'withdrawal',
        userEligible.smtp_price,
        userEligible.user_balance,
        newBalance,
        ipAddress,
        orderId,
        formattedCurrentTime,
        formattedCurrentTime


    ];

    try {
        const data: any = await executeQuery(query, params);
        return data;
    } catch (error) {
        console.error('Error fetching insertBuyLog():', error);
        throw error;
    }
}




export const getTicketList = async (userId: string | undefined) => {

    const query = `
    select id,last_replied_by,ticket_status,title, updated_at, created_at  from tickets
   where assigned_id = ? ;
    `;
    const params = [
        userId
    ];

    try {
        const data: any = await executeQuery(query, params);
        return data;
    } catch (error) {
        console.error('Error fetching getTicketList():', error);
        throw error;
    }
}




export const insertTicket = async (userId: string | undefined, data: any, ipAddress: string | undefined, user_type: string | undefined, encodedTitle: any) => {
    let userType = (user_type === 'SELLER' || user_type === 'BUYER') ? 'BUYER' : user_type;





    const query = `
    INSERT INTO tickets
    (
    issue_types_id, 
    creator_user_id,
    assigned_id,
    last_replied_by,
    ticket_status,
    title,
    created_at) 
VALUES 
    (?, ?, 
    ?,
    ?, ?,? , ?);
    
           `;
    const params = [
        data,
        userId,
        userId,
        userType,
        'open',
        encodedTitle,
        formattedCurrentTime
    ];

    try {
        const data: any = await executeQuery(query, params);
        return data;
    } catch (error) {
        console.error('Error fetching insertTicket():', error);
        throw error;
    }
}
export const insertTicketComment = async (userId: string | undefined, ipAddress: string | undefined, ticket_id: string | undefined, user_type: any, encodedTitle: any) => {
    let userType = (user_type === 'SELLER' || user_type === 'BUYER') ? 'BUYER' : user_type;
    const query = `
    insert into ticket_comments
    (
    ticket_id,
    author_user_id,
    author_user_type,
    author_comments,
    user_ip
    )
    values
    (?, ?, ?, ?, ?)
        
           `;
    const params = [
        ticket_id,
        userId,
        userType,
        encodedTitle,
        ipAddress
    ];

    try {
        const data: any = await executeQuery(query, params);
        return data;
    } catch (error) {
        console.error('Error fetching insertTicketComment():', error);
        throw error;
    }
}

export const isTicketEligible = async (ticket_id: string | undefined) => {
    //   let userType = (user_type === 'SELLER' || user_type === 'BUYER') ? 'BUYER' : user_type;
    const query = `
    select assigned_id 
    from tickets 
    where id = ?
    ;
        ;        
           `;
    const params = [
        ticket_id
    ];

    try {
        const data: any = await executeQuery(query, params);
        return data[0];
    } catch (error) {
        console.error('Error fetching getTicketComment():', error);
        throw error;
    }
}

export const getTicketComment = async (ticket_id: string | undefined, userId: string | undefined) => {
    //   let userType = (user_type === 'SELLER' || user_type === 'BUYER') ? 'BUYER' : user_type;
    const query = `
    select * from ticket_comments
    where ticket_id = ?
    ;        
           `;
    const params = [
        ticket_id
    ];

    try {
        const data: any = await executeQuery(query, params);
        return data;
    } catch (error) {
        console.error('Error fetching getTicketComment():', error);
        throw error;
    }
}
export const getTicketInfo = async (ticket_id: string | undefined,) => {
    //   let userType = (user_type === 'SELLER' || user_type === 'BUYER') ? 'BUYER' : user_type;
    const query = `
    select t1.title,t2.user_type,t1.ticket_status  
    from tickets t1
    join users t2 on t1.creator_user_id = t2.id
    where t1.id = ?
        ;        
           `;
    const params = [
        ticket_id
    ];

    try {
        const data: any = await executeQuery(query, params);
        return data[0];
    } catch (error) {
        console.error('Error fetching getTicketComment():', error);
        throw error;
    }
}



export const getTicketStatus = async (ticket_id: string | undefined,) => {
    const query = `
    select ticket_status,assigned_id
     from tickets
    where id = ?
    ;        
           `;
    const params = [
        ticket_id
    ];

    try {
        const data: any = await executeQuery(query, params);
        return data[0];
    } catch (error) {
        console.error('Error fetching getTicketComment():', error);
        throw error;
    }
}
export const balanceHistoryModal = async (userId: string | undefined) => {
    const query = `
    SELECT
    id,
    ROUND(amount, 2) AS amount,
    transaction_type AS type,
    ROUND(opening_balance, 2) AS openingBalance,
    ROUND(closing_balance, 2) AS closingBalance,
    updated_at AS date
FROM
    buyer_wallet_logs
WHERE
    buyer_id = ?
    AND transaction_type IN ('deposit', 'bonus')
    AND opening_balance > 0
ORDER BY
    updated_at DESC;

   ;      
           `;
    const params = [
        userId
    ];

    try {
        const data: any = await executeQuery(query, params);
        return data;
    } catch (error) {
        console.error('Error fetching balanceHistoryModal():', error);
        throw error;
    }
}