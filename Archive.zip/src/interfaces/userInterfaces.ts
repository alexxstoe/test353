import { z, ZodError } from 'zod';


export const signUpSchema = z.object({
    email: z.string().email(),
    password: z.string(),
    username: z.string(),
});

export type signUpType = z.input<typeof signUpSchema>; // string

export const loginSchema = z.object({
    email: z.string().email(),
    password: z.string(),
});

export type loginType = z.input<typeof loginSchema>; // string


