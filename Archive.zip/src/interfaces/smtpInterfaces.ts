import { Request } from 'express';


export interface SmtpData {
    host: string;
    port: number;
    user: string;
    password: string;
    category: string;
    price: string;
}
export interface registerData {
    email: string;
    password: number;
    username: string;
}
export interface loginData {
    email: string;
    password: number;
}


export interface RequestWithUserId extends Request {
    userId?: string;
    user_type?: string // Define userId property
}
export interface RequestWithSellerId extends Request {
    sellerId?: any; // Define userId property
}
