import { Request } from 'express';
import { z, ZodError } from 'zod';


export interface SmtpData {
    host: string;
    port: number;
    user: string;
    password: string;
    category: string;
    price: string;
}
export interface registerData {
    email: string;
    password: number;
    username: string;
}
export interface loginData {
    email: string;
    password: number;
}


export interface RequestWithUserId extends Request {
    userId?: string; // Define userId property
}


export const smtpListRequestBodySchema = z.object({
    hosting: z.string().regex(/^[a-zA-Z0-9]+$/).optional(), // Optional alphanumeric string
    location: z.string().regex(/^[a-zA-Z0-9]+$/).optional(), // Optional alphanumeric string
    webmail: z.enum(['0', '1', '2', '']).optional(), // Optional string: '0', '1', '2', or ''
    source: z.enum(['0', '1', '2', '']).optional(), // Optional string: '0', '1', '2', or ''
    seller: z.string().regex(/^[a-zA-Z0-9]+$/).optional(), // Optional alphanumeric string
    minPrice: z.string().refine(value => value === '' || parseFloat(value) > 0, {
        message: 'minPrice error'
    }).optional(), // Optional string: empty string or greater than 0
    maxPrice: z.string().refine(value => value === '' || parseFloat(value) > 0, {
        message: 'maxPrice error'
    }).optional(),
});
export const productBuySchema = z.object({
    id: z.string().regex(/^\d+$/).max(10), // Only accept strings containing integers with a maximum length of 10 characters
});
export const emailUpdateSchema = z.object({
    email: z.string().email(),
});

export const generateInvoiceSchema = z.object({
    amount: z.string().regex(/^\d{1,20}(\.\d{1,2})?$/)
        .refine(value => {
            const numericValue = parseFloat(value);
            return numericValue >= 5 && numericValue <= 1000;
        }, {
            message: 'Amount must be between 5 and 1000',
            path: ['amount']
        }),
    type: z.string().refine(value => ['1', '2', '3'].includes(value), {
        message: 'Type must be 1, 2, or 3',
        path: ['type']
    })
});




export interface blockLogInsertInter {
    status: string;
    addr: string;
    btcValue: number;
    txid: string;
}




// export const ticketPayloadSchema = z.object({
//     title: z.string().regex(/^[a-zA-Z0-9\s]+$/).max(39),
//     reason: z.string().refine(value => ['1', '2', '3', '4', '5'].includes(value), {
//         message: 'Reason must be one of: 1, 2, 3, 4, or 5',
//         path: ['reason']
//     }),
//     message: z.string()
// });
export const ticketPayloadSchema = z.object({
    title: z.string().max(39),
    reason: z.string().refine(value => ['1', '2', '3', '4', '5'].includes(value), {
        message: 'Reason must be one of: 1, 2, 3, 4, or 5',
        path: ['reason']
    }),
    message: z.string()
});
export const ticketCommentPayloadSchema = z.object({

    message: z.string(),
    ticketId: z.string(),
});

