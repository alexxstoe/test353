import { Request, Response } from "express";
import { StatusCodes } from "http-status-codes";
import nodemailer, { Transporter } from 'nodemailer';
import { dashboardDataModel, deleteSmtpById, massSmtpModel, smtpData, SmtpListModel, userData, userStats } from "../models/smtpModel";
import { RequestWithUserId } from "../interfaces/smtpInterfaces";
import { whoisData } from "../helpers/whoisData";
import { emailUpdateSchema, generateInvoiceSchema, productBuySchema, smtpListRequestBodySchema, ticketCommentPayloadSchema, ticketPayloadSchema } from "../interfaces/buyerInterfaces";
import { balanceHistoryModal, buyerBalanceAfterBuy, buyProductModel, changeStatusSold, getOrdersCount, getOrdersList, getTicketComment, getTicketInfo, getTicketList, getTicketStatus, insertBuyLog, insertInvoiceLog, insertTicket, insertTicketComment, isTicketEligible, updateTestMailModel, userOrderEligible } from "../models/buyerModel";
import blockonomics from "../helpers/blocknomics/blockonomics";
import axios from 'axios';
import DOMPurify from 'dompurify';
import { JSDOM } from 'jsdom';
import { v4 as uuidv4 } from 'uuid';

const QRCode = require('qrcode');
const fs = require('fs');
const IP = require('ip');



export const getSmtpList = async (req: RequestWithUserId, res: Response) => {

    const userId: string | undefined = req.userId; // Access userId from req object

    try {
        const parsed = smtpListRequestBodySchema.safeParse(req.body)
        if (!parsed.success) {


            return res.json('Invalid Payload',)
        }
        let filter = req.body;


        //  console.log("filter=>", filter)


        const response = await SmtpListModel(filter);
        const userDataa: any = await userData(userId);

        // console.log("response=>", response)
        // console.log(userDataa, 'userDataa')
        // console.log(userId, 'userId')


        return res.status(StatusCodes.OK).json({
            status: 'success',
            userData: userDataa,
            data: response,

        });
    } catch (error) {
        console.error('Error fetching SMTP list:', error);
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            status: 'error',
            message: 'Failed to fetch SMTP list'
        });
    }
};


export const getDashboard = async (req: RequestWithUserId, res: Response) => {
    try {
        const userId: string | undefined = req.userId; // Access userId from req object

        const response = await dashboardDataModel();
        let userAbout = await userStats(userId);
        console.log(userAbout, 'userAbout')

        let userData = {
            "balance": userAbout.balance,
            "email": userAbout.email,
            "tickets": userAbout.tickets,
            "reports": 535,
            "orders": userAbout.orders,
            "isSeller": (userAbout.user_type == 'SELLER' || userAbout.user_type == 'SUPPORT' || userAbout.user_type == 'ADMIN') ? true : false
        }
        const data = [
            {
                title: 'Cpanels',
                // value: response[0].cpanelCount,
                value: 646,
                url: '/cpanel',
            },
            {
                title: 'Shells',
                // value: response[0].shellCount,
                value: 466,
                url: '/shell',
            },
            {
                title: 'SSh/WHM',
                value: 66,

                // value: response[0].sshCount,
                url: '/sshwhm',
            },
            {
                title: 'RDP',
                // value: response[0].rdpCount,
                value: 96,

                url: '/rdp',
            },
            {
                title: 'SMTP',
                value: response[0].smtpCount,
                url: '/smtp',
            },
            {
                title: 'Mailer',
                value: 13,
                // value: response[0].rdpCount,
                url: '/mailer',
            },
        ];
        return res.status(StatusCodes.OK).json({
            status: 'success',
            userData: userData,
            data: data
        });
    } catch (error) {
        console.error('Error fetching Dashboard-Data:', error);
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            status: 'error',
            message: 'Failed to fetch Dashboard Data'
        });
    }
};
export const getOrders = async (req: RequestWithUserId, res: Response) => {
    try {
        const userId: string | undefined = req.userId; // Access userId from req object
        // const orderCount = await getOrdersCount(userId);
        const response = await getOrdersList(userId);
        // let userData = {
        //     "orders": orderCount.orderCount,
        // }

        return res.status(StatusCodes.OK).json({
            status: 'success',
            // userData: userData,
            data: response
        });
    } catch (error) {
        console.error('Error fetching Dashboard-Data:', error);
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            status: 'error',
            message: 'Failed to fetch Dashboard Data'
        });
    }
};



export const buyProduct = async (req: RequestWithUserId, res: Response) => {
    try {
        const parsed = productBuySchema.safeParse(req.body);
        if (!parsed.success) {
            return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ error: 'Invalid Payload' });
        }

        const { userId } = req;
        const { id: productId } = req.body;
        const ipAddress = IP.address();

        const userEligible = await userOrderEligible(productId, userId);
        console.log('userEligible', userEligible);

        const { smtp_status, isInOrders, user_balance, smtp_price } = userEligible;

        const isUserEligible = (
            smtp_status === 'UNSOLD' &&
            isInOrders === 'NO' &&
            user_balance != null &&
            smtp_price != null &&
            user_balance >= smtp_price
        );

        if (isUserEligible) {
            const response = await buyProductModel(productId, userId);
            //   console.log('responseeee', response);

            if (response.affectedRows > 0) {
                const changeStatus = await changeStatusSold(productId);

                if (changeStatus.affectedRows > 0) {
                    const newBalance = user_balance - smtp_price;
                    const updateBalanceOfUser = await buyerBalanceAfterBuy(userId, newBalance);
                    let orderId: any = response.insertId;
                    const updateLog = await insertBuyLog(userId, newBalance, userEligible, orderId, ipAddress);
                    console.log('updateLog', updateLog);

                    if (updateBalanceOfUser.affectedRows > 0) {
                        return res.status(StatusCodes.OK).json({ status: 'success' });
                    }
                }
            }
        }

        return res.status(StatusCodes.FORBIDDEN).json({ status: 'failed' });
    } catch (error) {
        console.error('Error buyProduct():', error);
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ status: 'failed', message: 'Failed to buy' });
    }
};





const smtpValidCheck = async (response: any, smtpID: any): Promise<boolean> => {
    console.log('response=>>>>>', response);
    const { host, port, username, password, test_email } = response;
    try {
        const transporter = nodemailer.createTransport({
            host: host,
            port: port,
            secure: false,
            auth: {
                user: username,
                pass: password,
            },
        });

        const isVerified = await new Promise<boolean>((resolve, reject) => {
            transporter.verify((error: Error | null, success: boolean) => {
                if (error) {
                    resolve(false); // SMTP verification failed
                } else {
                    resolve(true); // SMTP verification succeeded
                }
            });
        });

        if (isVerified) {
            try {
                let [first, last] = username.split('@');
                await transporter.sendMail({
                    from: username,
                    to: test_email,
                    subject: first,
                    text: `This is a test email from ${smtpID} SMTP server.`,
                });
            } catch (error) {
                return false; // Failed to send test email
            }
        }

        return isVerified; // Return true if SMTP verification succeeded, false otherwise
    } catch (error) {
        console.error('Error verifying SMTP configuration:', error);
        return false; // Error occurred while verifying SMTP configuration
    }
}


export const verifySmtp = async (req: RequestWithUserId, res: Response) => {
    try {
        const userId: string | undefined = req.userId; // Access userId from req object
        let smtpID = req.body.id;
        let response = await smtpData(smtpID, userId);
        let isValid = await smtpValidCheck(response[0], smtpID);

        if (!isValid) {
            // Delete SMTP if it's not valid
            await deleteSmtpById(smtpID); // Replace with your implementation
            console.log('SMTP deleted successfully.');
        }

        return res.status(StatusCodes.OK).json({
            status: isValid,
        });
    } catch (error) {
        console.error('Error fetching Dashboard-Data:', error);
        return res.status(StatusCodes.OK).json({
            status: false,
            //  message: 'Failed to fetch Dashboard Data'
        });
    }
};
export const updateTestMail = async (req: RequestWithUserId, res: Response) => {
    try {
        const parsed = emailUpdateSchema.safeParse(req.body);

        if (!parsed.success) {
            return res.status(StatusCodes.BAD_REQUEST).json({ error: 'Invalid payload' });
        }

        const userId: string | undefined = req.userId;
        const email = req.body.email;

        const response = await updateTestMailModel(userId, email);

        if (response.affectedRows > 0) {
            return res.status(StatusCodes.OK).json({ status: true });
        }

        return res.status(StatusCodes.FORBIDDEN).json({ status: false });
    } catch (error) {
        console.error('Error updating test mail:', error);
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ error: 'Failed to update test mail' });
    }
};
export const generateInvoice = async (req: RequestWithUserId, res: Response) => {
    try {
        const parsed = generateInvoiceSchema.safeParse(req.body);

        if (!parsed.success) {
            return res.status(StatusCodes.BAD_REQUEST).json({ error: 'Invalid payload' });
        }
        const newUUID = uuidv4();
        console.log('newUUID', newUUID)

        const userId: string | undefined = req.userId;
        const ipAddress = IP.address();

        const usdAmount = parseFloat(req.body.amount); // Parse the amount to float
        const blockonomicsResponse = await axios.get('https://www.blockonomics.co/api/price?currency=USD');
        const btcPrice = blockonomicsResponse.data.price;

        // Convert USD amount to BTC
        const btcAmount = parseFloat((usdAmount / btcPrice).toFixed(8));


        // Generate a new BTC address
        const newAddressResponse = await blockonomics.getNewAddress();
        const parsedResponse = JSON.parse(newAddressResponse);
        let newAddress = parsedResponse.address;
        let btcImg = await generateQRCodeBase64(newAddress)

        let insertLog = await insertInvoiceLog(newUUID, userId, usdAmount, newAddress, ipAddress)
        console.log('Insert', insertLog)
        return res.status(StatusCodes.OK).json({
            status: 'success',
            address: newAddress,
            btcAmount: btcAmount,
            usdAmount: usdAmount,
            qrCode: btcImg,
        });
    } catch (error) {
        console.error('Error generating invoice:', error);
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ error: 'Failed to generate invoice' });
    }
};


async function generateQRCodeBase64(address: string | undefined) {
    try {
        // Generate QR code as a Data URI
        const qrData = await QRCode.toDataURL(address);

        // Extract base64 string from Data URI
        const base64String = qrData.split(',')[1];

        console.log('QR code generated successfully');
        return base64String;
    } catch (error) {
        console.error('Error generating QR code:', error);
        throw error; // Propagate the error to the caller
    }
}




export const getTickets = async (req: RequestWithUserId, res: Response) => {

    const userId: string | undefined = req.userId; // Access userId from req object

    try {


        const response = await getTicketList(userId);
        // const userDataa: any = await userData(userId);

        // console.log("response=>", response)
        // console.log(userDataa, 'userDataa')
        // console.log(userId, 'userId')


        return res.status(StatusCodes.OK).json({
            status: 'success',
            // userData: userDataa,
            data: response,

        });
    } catch (error) {
        console.error('Error fetching SMTP list:', error);
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            status: 'error',
            message: 'Failed to fetch SMTP list'
        });
    }
};
//  optimize createTicket
export const createTicket = async (req: RequestWithUserId, res: Response) => {

    const userId: string | undefined = req.userId; // Access userId from req object
    const user_type: string | undefined = req.user_type; // Access userId from req object

    try {

        const parsed = ticketPayloadSchema.safeParse(req.body);

        if (!parsed.success) {
            return res.status(StatusCodes.BAD_REQUEST).json({ error: 'Invalid payload' });
        }
        let data: any = parsed.data;
        console.log(parsed.data);
        const ipAddress = IP.address();



        const { window } = new JSDOM('');
        const document = window.document;

        // Create a div element to parse and manipulate HTML
        const div = document.createElement('div');
        div.innerHTML = data.title;

        // Manipulate HTML (if needed)
        // For example, replacing <br> tags with newline characters
        div.querySelectorAll('br').forEach(br => {
            br.replaceWith(document.createTextNode('\n'));
        });

        // Get the processed HTML
        const formattedHTML = div.innerHTML;
        const encodedTitle = encodeURIComponent(formattedHTML);
        console.log(encodedTitle, 'encodedTitle');






        div.innerHTML = data.message;

        // Manipulate HTML (if needed)
        // For example, replacing <br> tags with newline characters
        div.querySelectorAll('br').forEach(br => {
            br.replaceWith(document.createTextNode('\n'));
        });

        // Get the processed HTML
        const formattedMessage = div.innerHTML;
        const encodedMessage = encodeURIComponent(formattedMessage);
        console.log(encodedMessage, 'encodedMessage');



        const response = await insertTicket(userId, parsed.data.reason, ipAddress, user_type, encodedTitle);
        console.log('response', response)
        const insertComment: any = await insertTicketComment(userId, ipAddress, response.insertId, user_type, encodedMessage);

        // console.log("response=>", response)
        // console.log(userDataa, 'userDataa')
        // console.log(userId, 'userId')


        return res.status(StatusCodes.OK).json({
            status: 'success',
            // userData: userDataa,
            //    data: response,

        });
    } catch (error) {
        console.error('Error createTicket()', error);
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            status: 'error',
            //  message: 'Failed to fetch SMTP list'
        });
    }
};



export const getTicketComments = async (req: RequestWithUserId, res: Response) => {

    const userId: string | undefined = req.userId; // Access userId from req object
    const ticketId: string = req.params.id;

    try {

        console.log(ticketId);
        console.log('userId', userId)

        const isEligibleToShow = await isTicketEligible(ticketId)
        console.log('isEligibleToShow', isEligibleToShow.assigned_id)

        if (isEligibleToShow.assigned_id === userId) {
            const response = await getTicketComment(ticketId, userId);
            const ticketInfo: any = await getTicketInfo(ticketId);


            return res.status(StatusCodes.OK).json({
                status: 'success',
                ticketInfo: ticketInfo,
                data: response,

            });

        } else return res.status(StatusCodes.OK).json({
            status: 'failer',
            // userData: userDataa,
            message: 'Not-Eligible',

        });


    } catch (error) {
        console.error('Error fetching getTicketComments()', error);
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            status: 'error',
            //   message: 'Failed to fetch SMTP list'
        });
    }
};




// Validate and create ticket comment
// export const createTicketComment = async (req: RequestWithUserId, res: Response) => {
//     const userId: string | undefined = req.userId;
//     const user_type: string | undefined = req.user_type;

//     try {
//         const parsed = ticketCommentPayloadSchema.safeParse(req.body);
//         if (!parsed.success) {
//             return res.status(StatusCodes.BAD_REQUEST).json({ error: 'Invalid payload' });
//         }
//         const data: any = parsed.data;

//         const sanitizedHTML = DOMPurify.sanitize(data.message);
//         const formattedHTML = sanitizedHTML.replace(/<br\s*\/?>/gm, '\n');
//         const encodedHTML = encodeURIComponent(formattedHTML);




//         const ipAddress = IP.address();

//         // Check if ticket is open and assigned to current user
//         const isTicketOpen = await getTicketStatus(data.ticketId);
//         if (isTicketOpen.ticket_status === 'open' && isTicketOpen.assigned_id == userId) {
//             // Insert comment
//             const insertComment = await insertTicketComment(userId, ipAddress, data.ticketId, user_type, encodedHTML);
//             if (insertComment.affectedRows > 0) {
//                 return res.status(StatusCodes.OK).json({ status: 'success' });
//             }
//         } else {
//             return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ status: 'error' });
//         }
//     } catch (error) {
//         console.error('Error createTicketComment()', error);
//         return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ status: 'error' });
//     }
// };



export const createTicketComment = async (req: RequestWithUserId, res: Response) => {
    const userId: string | undefined = req.userId;
    const user_type: string | undefined = req.user_type;

    try {
        const parsed = ticketCommentPayloadSchema.safeParse(req.body);
        if (!parsed.success) {
            return res.status(StatusCodes.BAD_REQUEST).json({ error: 'Invalid payload' });
        }
        const data: any = parsed.data;

        const { window } = new JSDOM('');
        const document = window.document;

        // Create a div element to parse and manipulate HTML
        const div = document.createElement('div');
        div.innerHTML = data.message;

        // Manipulate HTML (if needed)
        // For example, replacing <br> tags with newline characters
        div.querySelectorAll('br').forEach(br => {
            br.replaceWith(document.createTextNode('\n'));
        });

        // Get the processed HTML
        const formattedHTML = div.innerHTML;
        const encodedHTML = encodeURIComponent(formattedHTML);
        console.log(encodedHTML, 'encodedHTML')
        const ipAddress = IP.address();

        // Check if ticket is open and assigned to current user
        const isTicketOpen = await getTicketStatus(data.ticketId);
        //   console.log('isTicketOpen', isTicketOpen)
        if (isTicketOpen.ticket_status === 'open' && isTicketOpen.assigned_id == userId) {
            // Insert comment
            const insertComment = await insertTicketComment(userId, ipAddress, data.ticketId, user_type, encodedHTML);
            //  console.log(insertComment, 'insertComment')
            if (insertComment.affectedRows > 0) {
                return res.status(StatusCodes.OK).json({ status: 'success' });
            }
        } else {
            console.log('ticket closed or user not authorized');
            return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ status: 'error' });
        }
    } catch (error) {
        console.error('Error createTicketComment()', error);
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ status: 'error' });
    }
};



export const getBalanceHistory = async (req: RequestWithUserId, res: Response) => {
    try {
        const userId: string | undefined = req.userId; // Access userId from req object
        const response = await balanceHistoryModal(userId);

        return res.status(StatusCodes.OK).json({
            status: 'success',
            // userData: userData,
            data: response
        });
    } catch (error) {
        console.error('Error getBalanceHistory()', error);
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            status: 'error',
            message: 'Failed to fetch Balance Data'
        });
    }
};