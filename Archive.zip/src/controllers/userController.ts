import { Request, Response } from "express";
import { StatusCodes } from "http-status-codes";
import nodemailer, { Transporter } from 'nodemailer';
import { massSmtpModel, SmtpListModel } from "../models/smtpModel";
import { signUpSchema, loginSchema } from "../interfaces/userInterfaces";
import { loginModel, registerModel } from "../models/userModel";
const IP = require('ip');
import { RequestWithUserId } from "../interfaces/buyerInterfaces";

import jwt, { JwtPayload } from "jsonwebtoken";


export const registerUser = async (req: Request, res: Response) => {
    try {
        const parsed = signUpSchema.safeParse(req.body)
        if (!parsed.success) {
            return res.status(StatusCodes.FORBIDDEN).json({
                status: 'failed',
                // data: response
            });
        }

        let body = req.body;
        console.log(body)
        const response = await registerModel(body);
        console.log(response, 'response')

        if (response == 'Email-already-exists') {

            return res.status(StatusCodes.OK).json({
                status: 'duplicate',
                // data: response
            });


        }

        if (response) {
            return res.status(StatusCodes.OK).json({
                status: 'success',
                // data: response
            });
        } else {
            return res.status(StatusCodes.FORBIDDEN).json({
                status: 'failed',
                // data: response
            });


        }

    } catch (error) {
        console.error('Error Account Register', error);
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            status: 'error',
            message: 'Error Account Register'
        });
    }
};
export const loginUser = async (req: Request, res: Response) => {
    try {
        const parsed = loginSchema.safeParse(req.body)
        if (!parsed.success) {
            return res.json('Invalid Payload',)
        }


        let body = req.body;
        console.log(body)
        const response = await loginModel(body);
        console.log(response, 'responseeee')

        if (response.status === 'success') {
            let token;

            try {
                //Creating jwt token
                token = jwt.sign(
                    {
                        user_type: response.user_type,
                        userId: response.userId,
                        // email: existingUser.email
                    },
                    `${process.env.JWT_Token}`,
                    { expiresIn: "24h" }
                );
                res.cookie('token', token, {
                    //    maxAge: 86400000,
                    //  httpOnly: true, sameSite: 'strict' 
                });

                return res.status(StatusCodes.OK).json({
                    status: 'success',
                    //   data: token
                });
            } catch (err) {
                console.log(err);
                const error =
                    new Error("Error! Something went wrong.");
                return (error);
            }




        } else {
            return res.status(StatusCodes.FORBIDDEN).json({
                status: 'error',
                data: 'Invalid Email/Password'
            });


        }

    } catch (error) {
        console.error('Error Account Register', error);
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            status: 'error',
            message: 'Error Account Register'
        });
    }
};
export const logOutUser = async (req: Request, res: Response) => {
    try {

        res.clearCookie("token");


        return res.status(StatusCodes.OK).json({
            status: 'success',
        });


    } catch (error) {
        console.error('Error Account Logout', error);
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            status: 'error',
            message: 'Error Account Logout'
        });
    }
};






export const isSignedCheck = async (req: RequestWithUserId, res: Response) => {
    const token = req.cookies.token;

    // Check if token is provided
    if (!token) {
        return res.status(StatusCodes.NOT_FOUND).json({
            success: false,
            //    message: 'Token not found',
        });
    }

    try {
        const decoded = jwt.verify(token, `${process.env.JWT_Token}`) as JwtPayload;
        console.log(decoded, 'decoded');

        if (decoded.userId) {
            req.userId = decoded.userId;

            return res.status(StatusCodes.OK).json({
                success: true,
            });
        }
    } catch (error) {
        console.error('Error verifying JWT token:', error);
        return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            success: false,
            //    message: 'Internal server error',
        });
    }

    // This code should never be reached if the function returns above
    return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
        success: false,
        // message: 'Unexpected error',
    });
};
