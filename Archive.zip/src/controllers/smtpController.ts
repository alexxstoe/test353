import { Request, Response } from "express";
import { StatusCodes } from "http-status-codes";
import nodemailer, { Transporter } from 'nodemailer';
import { massSmtpModel } from "../models/smtpModel";
import { whoisData } from "../helpers/whoisData";
import { checkWebmail } from "../helpers/findWebmail";
import { RequestWithSellerId } from "src/interfaces/smtpInterfaces";
import socketIo from 'socket.io-client'; // Import socket.io-client




//  og code
export const addMassSmtp = async (req: RequestWithSellerId, res: Response) => {
    let { hosts, source, price, token } = req.body;
    const sellerId: any = req.sellerId; // Access sellerId from req object
    for (let i of hosts.split("\n")) {
        let [host, port, user, pass] = i.split("|");
        const transporter = nodemailer.createTransport({
            host: host,
            port: port,
            secure: false,
            auth: {
                user,
                pass,
            },
        });

        transporter.verify(async (error: Error | null, _success: boolean) => {
            if (error) {
                return console.error(`Error occurred while authenticating: ${host} `);
            } else {
                try {
                    const whoisInfo = await whoisData(host);
                    if (whoisInfo) {
                        let isWebmail = checkWebmail(host)
                        let addToDB: any = await massSmtpModel(host, port, user, pass, source, price, whoisInfo, isWebmail, sellerId);
                        //  console.log("addToDB=>", addToDB);
                        if (addToDB.affectedRows > 0) {
                            console.log(`Succfully added: ${host} `)

                        }
                        if (addToDB.code == 'ER_DUP_ENTRY') {
                            console.log(`Already added: ${host}`)
                        }
                    }
                } catch (error) {
                    console.error('Error occurred while fetching whois data or sending email:');
                }
            }
        });

    }

    return res.status(StatusCodes.OK).send('Added Successfully');
}

