import { Request, Response } from 'express';
import { blockLogInsert } from '../models/callBackModel';
import { buyerBalanceAfterBuy, buyerCurrentBalance, updateInvoiceLog } from '../models/buyerModel';
import axios from 'axios';

const secret = 'GopRo353';

// export const blocknomCallback = async (req: Request, res: Response) => {
//     try {
//         const { secret: callbackSecret, status, addr, txid, rbf } = req.query;
//         const value: string = req.query.value as string; // Asserting value as string

//         // console.log('Received payment callback:');
//         // console.log('Address:', addr);
//         // console.log('Value:', (value));
//         // console.log('Value (in BTC):', parseFloat(value) / 100000000); // Convert satoshis to BTC

//         // console.log('Transaction ID:', txid);
//         // console.log('query is:', req.query)


//         // Match secret for security
//         if (callbackSecret !== secret) {
//             return res.sendStatus(403); // Forbidden
//         }

//         // Only accept confirmed transactions
//         if (status !== '1') {
//             return res.sendStatus(200); // OK
//         }

//         // Optionally handle the RBF attribute if needed
//         if (rbf === '1') {
//             // Handle RBF transactions
//         }

//         // Update database or perform other actions
//         // For demonstration purposes, we're just logging the received data


//         console.log('Status:', status);

//         let btcValue = (parseFloat(value) / 100000000)
//         console.log('Value (in BTC):', parseFloat(value) / 100000000); // Convert satoshis to BTC

//         const blockonomicsResponse = await axios.get('https://www.blockonomics.co/api/price?currency=USD');
//         const btcPrice = blockonomicsResponse.data.price;

//         let usdAmount = btcValue * btcPrice;
//         console.log('usdAmount', usdAmount);
//         let insertDB = await blockLogInsert(status, addr, btcValue, txid);
//         let curBalance = await buyerCurrentBalance(addr);
//         const balanceNow = parseFloat(curBalance.balance).toFixed(2);
//         const newBalance = (parseFloat(balanceNow) + usdAmount).toFixed(2);

//         console.log('newBalance', newBalance)
//         let updateLog = await updateInvoiceLog(status, addr, usdAmount, txid, balanceNow, newBalance)
//         //  console.log(insertDB, 'insertDB');

//         console.log('updateLog', updateLog)

//         let finalBalanceUpdated = await buyerBalanceAfterBuy(curBalance.user_id, newBalance)
//         console.log('finalBalanceUpdated', finalBalanceUpdated)
//         // Send success response
//         res.sendStatus(200); // OK
//     } catch (error) {
//         console.error('Error processing callback:', error);
//         res.sendStatus(500); // Internal Server Error
//     }
// };



export const blocknomCallback = async (req: Request, res: Response) => {
    try {
        const { secret: callbackSecret, status, addr, txid, rbf } = req.query;

        // Match secret for security
        if (callbackSecret !== secret) {
            return res.sendStatus(403); // Forbidden
        }

        // Only accept confirmed transactions
        if (status !== '1') {
            return res.sendStatus(200); // OK
        }

        // Optionally handle the RBF attribute if needed
        if (rbf === '1') {
            // Handle RBF transactions
        }

        const btcValue = parseFloat(req.query.value as string) / 100000000;
        const blockonomicsResponse = await axios.get('https://www.blockonomics.co/api/price?currency=USD');
        const btcPrice = blockonomicsResponse.data.price;
        const usdAmount = btcValue * btcPrice;

        // Perform database operations only if necessary
        const insertDB = await blockLogInsert(status, addr, btcValue, txid);
        if (insertDB.affectedRows > 0) {
            const curBalance = await buyerCurrentBalance(addr);
            if (curBalance.balance && curBalance.user_id) {
                const balanceNow = parseFloat(curBalance.balance).toFixed(2);
                const newBalance = (parseFloat(balanceNow) + usdAmount).toFixed(2);
                const updateLog = await updateInvoiceLog(status, addr, usdAmount, txid, balanceNow, newBalance);
                if (updateLog.affectedRows > 0) {
                    const finalBalanceUpdated = await buyerBalanceAfterBuy(curBalance.user_id, newBalance);
                    // Log the final balance updated
                    console.log('Final balance updated:', finalBalanceUpdated);
                    // Send success response
                    return res.sendStatus(200); // OK
                }
            }
        }

        // If any condition fails or no database operation performed, send internal server error
        res.sendStatus(500); // Internal Server Error

    } catch (error) {
        console.error('Error processing callback:', error);
        res.sendStatus(500); // Internal Server Error
    }
};

