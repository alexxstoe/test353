import express, { Router } from 'express';
import { addMassSmtp } from '../controllers/smtpController';
import { isSeller } from '../middlewares/auth';
const smtpRoute: Router = express.Router();
//import { StatusCodes } from "http-status-codes";

// Health check route

smtpRoute.post('/add-mass-smtp',
    // isSeller,
    addMassSmtp);


export default smtpRoute;


