import express, { Router, } from 'express';
import { buyProduct, verifySmtp, getDashboard, getOrders, getSmtpList, updateTestMail } from '../controllers/buyerController';
import { authCookie } from '../middlewares/auth';
import { blocknomCallback } from '../controllers/callBackController';
const handleCallbackRoute: Router = express.Router();
//import { StatusCodes } from "http-status-codes";

// Health check route

handleCallbackRoute.get('/callback_url', blocknomCallback);


export default handleCallbackRoute;
