import express, { Router } from 'express';
import { isSignedCheck, loginUser, logOutUser, registerUser } from '../controllers/userController';
const userRoute: Router = express.Router();
//import { StatusCodes } from "http-status-codes";

// Health check route

userRoute.post('/register', registerUser);
userRoute.post('/login', loginUser);
userRoute.get('/signed', isSignedCheck);
userRoute.get('/logout', logOutUser);


export default userRoute;
