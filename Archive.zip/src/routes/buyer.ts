import express, { Router, } from 'express';
import { buyProduct, verifySmtp, getDashboard, getOrders, getSmtpList, updateTestMail, generateInvoice, getTickets, createTicket, getTicketComments, createTicketComment, getBalanceHistory } from '../controllers/buyerController';
import { authCookie } from '../middlewares/auth';
// import { getNewAddressController } from '../controllers/smtpController';
const buyerRoute: Router = express.Router();
//import { StatusCodes } from "http-status-codes";

// Health check route

buyerRoute.post('/smtp-list', authCookie, getSmtpList);
buyerRoute.post('/tickets', authCookie, getTickets);
buyerRoute.post('/tickets/:id', authCookie, getTicketComments);


buyerRoute.post('/create-ticket', authCookie, createTicket);
buyerRoute.post('/create-comment', authCookie, createTicketComment);
buyerRoute.post('/get-invoice', authCookie, generateInvoice);
// buyerRoute.post('/newAddress', authCookie, getNewAddressController);
buyerRoute.post('/smtp-check', authCookie, verifySmtp);
buyerRoute.post('/buy-tool', authCookie, buyProduct);
buyerRoute.post('/get-orders', authCookie, getOrders);
buyerRoute.post('/balance-history', authCookie, getBalanceHistory);
buyerRoute.post('/test-mail-update', authCookie, updateTestMail);
buyerRoute.get('/dashboard',
    authCookie,
    getDashboard);


export default buyerRoute;
