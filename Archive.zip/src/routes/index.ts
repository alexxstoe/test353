import express from 'express';
// import logger from '../utils/logger';
// import { healthCheck } from 'src/handlers/healthcheck';
// import {healthCheck} from '../handler/healthCheck'

const router = express.Router();

/* GET home page. */
router.get('/', (_req, res) => {
    res.send("yo")
});
router.get('/add-mass-smtp', (_req, res) => {
    res.send("yo")
});

export default router;
