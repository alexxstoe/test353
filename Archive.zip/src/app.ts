import createError from 'http-errors';
import express, { Application } from 'express';
import path from 'path';
import dotenv from 'dotenv';
import cookieParser from 'cookie-parser';
import http from 'http';
var cors = require('cors')
dotenv.config({ path: path.join(__dirname, '../.env') });
import { handleError } from './helpers/error';
import httpLogger from './middlewares/httpLogger';
import router from './routes/index';
import smtpRoute from './routes/smtp';
import buyerRoute from './routes/buyer';
import { dbConnect, executeQuery } from './helpers/db';
import userRoute from './routes/user';
import blockonomics from './helpers/blocknomics/blockonomics';
import handleCallbackRoute from './routes/callback';
const rateLimit = require('express-rate-limit');




const app: Application = express();
const server = http.createServer(app);

// Export the server instance

// Pass the server instance to the handleWebSocket function
// handleWebSocket(httpServer);
// Initialize WebSocket server and pass the HTTP server instance


// dbConnect();

// Route to get a new address





const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 500, // Limit each IP to 500 requests per windowMs
  message: 'Too many requests from this IP, please try again later.'
});


app.use(limiter);
// app.disable('x-powered-by');
app.use(httpLogger);
app.use(express.json());
app.use(cookieParser());
app.use(express.urlencoded({ extended: true }));
app.use(cors({
  credentials: true,
  origin: "http://localhost:5173"
  // origin: "http://3.110.56.174:3000"
}));

app.use('/api', router);
app.use('/api/seller/smtp', smtpRoute);
app.use('/api/buyer', buyerRoute);
app.use('/api/user', userRoute);
app.use('/api/warzone', handleCallbackRoute);



// catch 404 and forward to error handler
app.use((_req, _res, next) => {
  next(createError(404));
});

// error handler
const errorHandler: express.ErrorRequestHandler = (err, _req, res) => {
  handleError(err, res);
};
app.use(errorHandler);

const port = process.env.PORT || '8000';
app.set('port', port);


//const server = http.createServer(app);
// console.log('dbConnection', dbConnection)
function onError(error: { syscall: string; code: string }) {
  if (error.syscall !== 'listen') {
    throw error;
  }

  // handle specific listen errors with friendly messages
  switch (error.code) {
    case 'EACCES':
      process.exit(1);
      break;
    case 'EADDRINUSE':
      process.exit(1);
      break;
    default:
      throw error;
  }
}

function onListening() {
  const addr = server.address();
  const bind = typeof addr === 'string' ? `pipe ${addr}` : `port ${addr?.port}`;
  console.info(`Server is listening on ${bind}`);
}

dbConnect()
  .then(() => {
    app.listen(port, () => {
      console.log(`Server is running on port ${port}`);
    });
  })
  .catch(err => {
    console.error('Error connecting to database:', err);
  }); server.on('error', onError);
server.on('listening', onListening);


