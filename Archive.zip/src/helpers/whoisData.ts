import axios from 'axios';

export const whoisData = async (domain: string): Promise<any> => {
    try {
        const API_KEY = process.env.Whois_API as string;
        const response = await axios.get<any>('https://ip-geolocation.whoisxmlapi.com/api/v1', {
            params: {
                apiKey: API_KEY,
                domain: domain
            }
        });
        //  console.log(response);
        return response.data;
    } catch (error) {
        //  console.error('Error occurred during IP geolocation lookup:', error);
        throw error;
    }
};
