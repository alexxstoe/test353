import querystring from 'querystring';
import { config } from './config';
import http from 'http';
import https from 'https'; // Add this line to import the 'https' module

interface RequestOptions {
    url: string;
    qs?: object;
    method: string;
    headers: {
        'Content-Type': string;
        'User-Agent': string;
        'Accept': string;
        'Authorization': string;
    };
}

export default {
    getBalance(addr: string) {
        const url = config.balance;
        const result = sendRequest(url, 'POST', { "addr": addr });
        return result;
    },

    getHistory(addr: string) {
        const url = config.history;
        const result = sendRequest(url, 'POST', { "addr": addr });
        return result;
    },

    getTransactionDetail(txId: string) {
        const url = config.transactionDetail + `?txid=${txId}`;
        const result = sendRequest(url, "GET", {});
        return result;
    },

    getTransactionReceipt(txId: string, addr: string) {
        const url = config.transactionReceipt + `?txid=${txId}&addr=${addr}`;
        const result = sendRequest(url, "GET", {});
        return result;
    },

    getAccountBalance(APIKEY: string) {
        const url = config.address;
        const result = sendRequest(url, "GET", {}, APIKEY);
        return result;
    },

    insertAddress(APIKEY: string, addr: string, tag: string) {
        const url = config.address;
        const result = sendRequest(url, "POST", { "addr": addr, "tag": tag }, APIKEY);
        return result;
    },

    deleteAddress(APIKEY: string, addr: string) {
        const url = config.delete_address;
        const result = sendRequest(url, "POST", { "addr": addr }, APIKEY);
        return result;
    },


    // getNewAddress(reset: number, match_account: string) {
    //     let url = config.newAddress;
    //     if (reset === 1)
    //         url += "?reset=1"; // Use "?" for the first parameter

    //     if (match_account)
    //         url += (reset === 1 ? "&" : "?") + `match_account=${match_account}`; // Use "&" for subsequent parameters

    //     const result = sendRequest(url, "POST", {}, process.env.BlockNo_Token);
    //     return result;
    // }
    getNewAddress() {
        let url = config.newAddress;
        // if (reset === 1)
        // url += "?reset=1"; // Use "?" for the first parameter

        // if (match_account)
        //     url += (reset === 1 ? "&" : "?") + `match_account=${match_account}`; // Use "&" for subsequent parameters

        const result = sendRequest(url, "POST", {}, process.env.BlockNo_Token);
        return result;
    }

};

function sendRequest(fullpath: string, method: string, querystring: object, APIKEY?: string): Promise<any> {
    const options: RequestOptions = {
        url: config.hostUrl + fullpath,
        qs: querystring,
        method: method,
        headers: {
            'Content-Type': 'application/json',
            'User-Agent': 'blockonomics',
            'Accept': 'application/json',
            'Authorization': `Bearer ${APIKEY}`
        }
    };

    return new Promise((resolve, reject) => {
        let protocol: typeof import('http') | typeof import('https'); // Define the protocol type
        if (options.url.startsWith('https://')) {
            protocol = require('https'); // Use require for dynamic import
        } else {
            protocol = require('http'); // Use require for dynamic import
        }

        const req = protocol.request(options.url, {
            method: options.method,
            headers: options.headers
        }, (response) => {
            let data = '';

            response.on('data', (chunk) => {
                data += chunk;
            });

            response.on('end', () => {
                resolve(data);
            });
        });

        req.on('error', (error) => {
            reject(error);
        });

        if (options.method === 'POST') {
            req.write(JSON.stringify(options.qs));
        }

        req.end();
    });
}