export interface Config {
    apiVersion: number;
    apiKey: string;
    hostUrl: string;
    balance: string;
    history: string;
    transactionDetail: string;
    transactionReceipt: string;
    address: string;
    delete_address: string;
    newAddress: string;
    callback: string;
    payment: string;
}

export const config: Config = {
    apiVersion: 1.0,
    apiKey: 'NxdbwC9tT2lgwqXGbXd3CsH7hu9USa3HwPPedD9oEyc',
    hostUrl: 'https://www.blockonomics.co',
    balance: '/api/balance',
    history: '/api/searchhistory',
    transactionDetail: '/api/tx_detail',
    transactionReceipt: '/api/tx',
    address: '/api/address',
    delete_address: '/api/delete_address',
    newAddress: '/api/new_address',
    callback: '/api/callback_url',
    payment: '/payment/',
};
