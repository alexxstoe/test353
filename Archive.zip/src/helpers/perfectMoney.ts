import axios from 'axios';

interface HiddenFields {
    [key: string]: string;
}

const requestData = {
    AccountID: '5823223',
    PassPhrase: 'a259p77WVScFGgNDfSlVEqrVq',
    Payer_Account: 'U23813962',
    Amount: '12.40'
};

axios.get<string>('https://perfectmoney.com/acct/ev_create.asp', { params: requestData })
    .then((response) => {
        const hiddenFields: HiddenFields = {};
        const regex = /<input name='(.*)' type='hidden' value='(.*)'>/g;
        let match;

        while ((match = regex.exec(response.data)) !== null) {
            hiddenFields[match[1]] = match[2];
        }

        console.log(hiddenFields);
    })
    .catch((error: any) => {
        console.error('Error opening URL:', error);
    });
