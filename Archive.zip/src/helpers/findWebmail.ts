import axios, { AxiosError, AxiosResponse } from 'axios';

export async function checkWebmail(domain: string): Promise<boolean | undefined> {
    const webmailUrl = `http://${domain}/webmail`;
    try {
        const response: AxiosResponse<any> = await axios.get(webmailUrl, { timeout: 2150 }); // Set timeout to 2.5 seconds (2500 milliseconds)
        if (response.status === 200) {
            return true;
        }
    } catch (error) {
        if (axios.isAxiosError(error)) {
            // Axios error occurred (e.g., timeout)
            //   console.error(`Error checking webmail interface at ${webmailUrl}:`, error.message);
        } else {
            // Non-Axios error occurred
            //   console.error(`Non-Axios error checking webmail interface at ${webmailUrl}:`, error);
        }
    }
    return false; // Return false if there's an error or no response
}
