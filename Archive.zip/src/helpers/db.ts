

import mysql, { Pool, PoolConnection } from 'mysql2/promise';

let pool: Pool;

export const dbConnect = async () => {
    pool = await mysql.createPool({
        host: process.env.DB_HOST || 'localhost',
        user: process.env.DB_USER || 'root',
        password: process.env.DB_PASSWORD || '',
        database: process.env.DB || 'my_database',
        waitForConnections: true,
        port: 22842,
        connectionLimit: 10,
        queueLimit: 0
    });

    // Test the connection
    try {
        const connection = await pool.getConnection();
        console.log('Connected to database');
        connection.release(); // Release the connection
    } catch (err) {
        console.error('Error connecting to database:', err);
    }
}

export async function executeQuery(query: string, params: any[] = []) {
    try {
        if (!pool) {
            await dbConnect(); // Establish database connection

            throw new Error('Database connection not established');
        }
        const connection: PoolConnection = await pool.getConnection();
        const [rows, fields] = await connection.query(query, params);
        connection.release();
        return rows;
    } catch (error) {
        console.error('Error executing query:', error);
        throw error;
    }
}

// Example usage

// exampleUsage(); // Call exampleUsage to execute the query
